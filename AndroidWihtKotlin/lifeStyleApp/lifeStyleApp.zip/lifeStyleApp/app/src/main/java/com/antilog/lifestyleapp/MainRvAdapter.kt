package com.antilog.lifestyleapp

import android.content.Context
import androidx.appcompat.app.AlertController

class MainRvAdapter (val context: Context, val list:ArrayList<Model>) : Recy