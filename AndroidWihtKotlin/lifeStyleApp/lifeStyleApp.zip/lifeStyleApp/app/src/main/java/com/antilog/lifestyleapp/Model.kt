package com.antilog.lifestyleapp

import android.icu.text.CaseMap

data class Model(
    val title: String,
    val image: String
)