package com.antilog.semina_3rd_task2.data.home_fragment

data class HomeData(
    val userName: String,
    val img_profile: String,
    val img_contents:String
)