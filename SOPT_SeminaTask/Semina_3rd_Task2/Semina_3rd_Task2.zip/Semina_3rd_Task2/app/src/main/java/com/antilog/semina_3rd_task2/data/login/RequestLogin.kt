package com.antilog.semina_3rd_task2.data.login

data class RequestLogin(
    val id: String,
    val password : String
)