package com.antilog.semina_3rd_task2.data.register

data class ResponseRegister(
    val status : Int,
    val success : Boolean
)